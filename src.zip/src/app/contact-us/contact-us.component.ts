import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [],
  template: `
    <p>
      contact-us works!
    </p>
  `,
  styleUrl: './contact-us.component.css'
})
export class ContactUsComponent {

}
