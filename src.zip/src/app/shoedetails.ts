export interface Shoedetails {
        id: number,
        model: string,
        make: string,
        Year: string,
        photo: string,
        availableUnits: number,
        used: boolean,
        resale: boolean,
}

