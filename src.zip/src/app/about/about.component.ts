import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [],
  template: `
    <p>
      about works!
    </p>
  `,
  styleUrl: './about.component.css'
})
export class AboutComponent {

}
